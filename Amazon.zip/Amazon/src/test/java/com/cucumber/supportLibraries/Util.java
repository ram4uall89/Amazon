package com.cucumber.supportLibraries;

import cucumber.api.Scenario;

public class Util {

	protected Scenario currentScenario;

	public void embedScreenshotStep(Scenario scenario) {
		currentScenario = scenario;
	}

}
