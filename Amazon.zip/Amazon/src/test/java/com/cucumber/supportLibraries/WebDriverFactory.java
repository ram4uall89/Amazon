package com.cucumber.supportLibraries;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverFactory {

	private static String browserName;
	private static String testURL;
	private static String chromeDriverPath;
	private static String projectDirectory = System.getProperty("user.dir");
	private static long waitTime;
	public static WebDriver driver;

	public static WebDriver instantiateDriver() {
		try {
			InputStream input = new FileInputStream(
					projectDirectory + "/src/test/resources/Properties/Settings.properties");
			Properties prop = new Properties();
			prop.load(input);
			browserName = prop.getProperty("Browser");
			testURL = prop.getProperty("URL");
			chromeDriverPath = prop.getProperty("ChromeDriverPath");
			waitTime = Long.parseLong(prop.getProperty("ImplicitWaitTime"));

			switch (browserName) {
			case "Chrome":
				System.setProperty("webdriver.chrome.driver", chromeDriverPath);
				driver = new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);
				driver.get(testURL);
				driver.manage().window().maximize();
			case "Firefox":
				// Need to add for ff driver
			}
		} catch (Exception e) {
			System.out.println("Exception in instantiate Driver" + e);
		}
		return driver;
	}

	public void killDriver() {
		try {
			driver.close();
		} catch (Exception e) {
			System.out.println("Exception in kill Driver " + e);
		}

	}

	public void click(By webObj, String ObjName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(webObj));
			element.click();
			System.out.println("Object clicked: " + ObjName);
		} catch (Exception e) {
			System.out.println("click Exception " + e);
		}
	}

	public void verifyElementPresent(By webObj, String ObjName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(webObj));
			Assert.assertTrue(element.isDisplayed(), "Element present: " + ObjName);
		} catch (Exception e) {
			System.out.println("verify Element Present - Exception " + e);
		}

	}
	
	public void enterText(By webObj, String valueToEnter, String ObjName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(webObj));
			element.sendKeys(valueToEnter);
			System.out.println("Value entered: "+valueToEnter + " in text box: " + ObjName);
		} catch (Exception e) {
			System.out.println("click Exception " + e);
		}
	}

}
