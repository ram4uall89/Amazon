package com.cucumber.stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cucumber.supportLibraries.Util;
import com.cucumber.stepMethods.AmazonMethods;

public class AmazonStepDefinition extends Util{
	
	private AmazonMethods amazonStore = new AmazonMethods();	 
	@Given("^Amazon website is launched$")
	public void amazondotcomWebsiteIsLaunched() {
		amazonStore.verifyCartElementPresent();
	}
	
	@Given("^User enters \"([^\"]*)\" in Amazon Search bar$")
	public void userEntersHeadphonesInAmazonSearchBar(String arg1) {
		amazonStore.enterValueInSearchBox(arg1);
	}

	@When("^User clicks on Search button$")
	public void userClicksOnSearchButton() {
		amazonStore.clickSearch();
	}

	@Then("^User is displayed with Best Selling Headphones$")
	public void userIsDisplayedWithBestSellingHeadphones() {
//		currentScenario.write("testqwr2");
	}

	@When("^User add all Best Selling Headphones to the cart$")
	public void userAddAllBestSellingHeadphonesToTheCart() {
		amazonStore.findAllBestSellingProductsAndAddToCart();
	}

	@Then("^Cart should contains all the added Headphones$")
	public void cartShouldContainsAllTheAddedHeadphones() {
//		currentScenario.write("testr123");
	}
}
