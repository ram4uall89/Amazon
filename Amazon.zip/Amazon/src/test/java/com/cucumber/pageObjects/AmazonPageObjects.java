package com.cucumber.pageObjects;

import org.openqa.selenium.By;

public class AmazonPageObjects {
	// image
	public static By imgCart = By.xpath("//*[@id='nav-cart']");
	public static By imgSearch = By.xpath("//input[@type='submit'][@value='Go']");
	public static By imgProductswithBestSellers = By.xpath("//span[contains(text(),'Best Seller')]"
			+ "/ancestor::div[@class='a-section a-spacing-medium']/div[2]/div/div/div/span/a/div/img");
	// textBox
	public static By txtBoxSearch = By.xpath("//input[contains(@id,'searchtextbox')]");
	// button
	public static By buttonAddToCart = By.xpath("//input[@id='add-to-cart-button']");

}
