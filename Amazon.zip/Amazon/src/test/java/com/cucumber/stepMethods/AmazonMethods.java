package com.cucumber.stepMethods;

import com.cucumber.supportLibraries.WebDriverFactory;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.pageObjects.AmazonPageObjects;

public class AmazonMethods extends WebDriverFactory {
	
	public void verifyCartElementPresent()  {
		verifyElementPresent(AmazonPageObjects.imgCart, "Cart");
	}
	
	public void enterValueInSearchBox(String valueToSend) {
		enterText(AmazonPageObjects.txtBoxSearch,"Headphones","Search Products");
	}
	
	public void clickSearch() {
		click(AmazonPageObjects.imgSearch,"Search glass icon");
	}
	
	public void findAllBestSellingProductsAndAddToCart() {
		try {
			List<WebElement> bestSellingProducts = driver.findElements(AmazonPageObjects.imgProductswithBestSellers);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			for(WebElement product : bestSellingProducts){
				wait.until(ExpectedConditions.elementToBeClickable(product));
				
				Actions oAction=new Actions(driver);
//				oAction.moveToElement(product);
//				oAction.contextClick(product).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER);
//				oAction.build().perform();
//				product.sendKeys(Keys.CONTROL + "t");
				product.click();

			    click(AmazonPageObjects.buttonAddToCart,"Add To Cart button");
				driver.navigate().back();
				driver.navigate().refresh();
			}
		} catch (Exception e) {
			System.out.println("click Exception " + e);
		
		}
	}
}
